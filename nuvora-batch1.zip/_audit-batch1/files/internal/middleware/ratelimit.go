package middleware

import (
	"net"
	"net/http"
	"sync"
	"time"

	"ykay-virtual/pkg"
)

type RateLimiter struct {
	mu       sync.Mutex
	requests map[string][]time.Time
	// lastSeen tracks the most recent request time per key so that entries
	// whose sliding window has fully lapsed can be evicted. Without this the
	// map grows forever (one entry per distinct source IP), an unbounded-memory
	// leak that becomes an OOM vector under sustained traffic (CF-3).
	lastSeen map[string]time.Time
	limit    int
	window   time.Duration
}

// maxLimiterEntries bounds the number of tracked keys. When exceeded, entries
// idle for at least one full window are pruned to keep memory bounded.
const maxLimiterEntries = 10000

func NewRateLimiter(limit int, window time.Duration) *RateLimiter {
	return &RateLimiter{
		requests: make(map[string][]time.Time),
		lastSeen: make(map[string]time.Time),
		limit:    limit,
		window:   window,
	}
}

func (rl *RateLimiter) Middleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Key on the bare IP (not ip:port) so keep-alive/new connections from
		// the same client cannot bypass the window.
		ip := r.RemoteAddr
		if host, _, err := net.SplitHostPort(ip); err == nil {
			ip = host
		}
		rl.mu.Lock()
		now := time.Now()
		cutoff := now.Add(-rl.window)
		times := rl.requests[ip]
		filtered := []time.Time{}
		for _, t := range times {
			if t.After(cutoff) {
				filtered = append(filtered, t)
			}
		}
		if len(filtered) >= rl.limit {
			rl.mu.Unlock()
			pkg.WriteError(w, http.StatusTooManyRequests, string(pkg.CodeTooManyRequests),
				"too many requests, please slow down", nil)
			return
		}
		filtered = append(filtered, now)
		rl.requests[ip] = filtered
		rl.lastSeen[ip] = now
		rl.maybePrune(now)
		rl.mu.Unlock()
		next.ServeHTTP(w, r)
	})
}

// maybePrune removes entries whose most recent request predates the sliding
// window. It runs opportunistically when the tracked-key count grows past the
// bound, keeping the per-IP cost O(1) on the common path (CF-3).
func (rl *RateLimiter) maybePrune(now time.Time) {
	if len(rl.requests) <= maxLimiterEntries {
		return
	}
	idleBefore := now.Add(-rl.window)
	for ip, last := range rl.lastSeen {
		if last.Before(idleBefore) {
			delete(rl.requests, ip)
			delete(rl.lastSeen, ip)
		}
	}
}
